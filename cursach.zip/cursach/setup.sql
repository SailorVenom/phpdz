CREATE SCHEMA db_kate;
CREATE USER 'kate'@'localhost'
  identified with mysql_native_password
  by 'kate';
GRANT ALL PRIVILEGES ON db_kate.* TO 'kate'@'localhost';
USE db_kate;

CREATE TABLE users
(
    id int PRIMARY KEY NOT NULL AUTO_INCREMENT,
    email varchar(64) NOT NULL,
    username varchar(64) NOT NULL,
    password varchar(64) NOT NULL,
    admin int DEFAULT 0 NULL
);
CREATE UNIQUE INDEX users_id_uindex ON users (id);
CREATE UNIQUE INDEX users_email_uindex ON users (email);
CREATE UNIQUE INDEX users_username_uindex ON users (username);
INSERT INTO `users` (`email`, `username`, `password`, `admin`) VALUES ('---', 'kate', 'kate', 1);

CREATE TABLE breeds
(
  id int PRIMARY KEY NOT NULL AUTO_INCREMENT,
  image varchar(128),
  breed varchar(64) NOT NULL,
  info text,
  rating float DEFAULT 0
);
CREATE UNIQUE INDEX breeds_id_uindex ON breeds (id);

CREATE TABLE rates
(
  id int PRIMARY KEY NOT NULL AUTO_INCREMENT,
  breed_id int NOT NULL,
  user_id int NOT NULL,
  rate int NOT NULL
);
CREATE UNIQUE INDEX rates_id_uindex ON rates (id);
CREATE TABLE comments
(
  id int PRIMARY KEY NOT NULL AUTO_INCREMENT,
  breed_id int NOT NULL,
  user_id int NOT NULL,
  comment text NOT NULL,
  username varchar(64) NOT NULL
);
CREATE UNIQUE INDEX comments_id_uindex ON comments (id);
