<?php
session_start();
require "db.php";
$conn = mysqli_connect($dbservername, $dbusername, $dbpassword, $dbname);
if ($_SESSION["user"]) {
    $user = $_SESSION["user"];
} else {
    $user = 0;
}
require "htmlstart.php";
require "navbar.php";
?>
<?php
session_destroy();
header('Location: login.php');
?>
<?php
mysql_close($conn);
require "htmlend.php";
?>
