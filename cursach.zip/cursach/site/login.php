<?php
session_start();
require "db.php";
$conn = mysqli_connect($dbservername, $dbusername, $dbpassword, $dbname);
if ($_SESSION["user"]) {
    $user = $_SESSION["user"];
} else {
    $user = 0;
}
require "htmlstart.php";
require "navbar.php";
?>
<?php
if ($_SERVER["REQUEST_METHOD"]=="POST" && !$user) {
    $username = $_POST["username"];
    $password = $_POST["password"];
    $query = "SELECT * FROM `users` WHERE `username`=\"$username\" AND `password`=\"$password\";";
    $res = mysqli_query($conn, $query);
    if (mysqli_num_rows($res)==1) {
        $row = mysqli_fetch_assoc($res);
        $user = array();
        $user["id"] = $row["id"];
        $user["email"] = $row["email"];
        $user["username"] = $row["username"];
        $user["admin"] = $row["admin"];
        $_SESSION["user"] = $user;
        if (mysqli_query($conn, $query)) {
            header('Location: index.php');
        }
    }
}
?>
<form action="login.php" method="post" class="form">
    <h2>Login</h2>
    <h4>Username</h4>
    <input name="username" type="text" required><br>
    <h4>Password</h4>
    <input name="password" type="password" required><br>
    <button type="submit">Login!</button>
</form>
<?php
mysql_close($conn);
require "htmlend.php";
?>
