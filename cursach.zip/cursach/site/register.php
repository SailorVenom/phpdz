<?php
session_start();
require "db.php";
$conn = mysqli_connect($dbservername, $dbusername, $dbpassword, $dbname);
if ($_SESSION["user"]) {
    $user = $_SESSION["user"];
} else {
    $user = 0;
}
require "htmlstart.php";
require "navbar.php";
?>
<?php
if ($_SERVER["REQUEST_METHOD"]=="POST" && !$user) {
    $email = $_POST["email"];
    $username = $_POST["username"];
    $password = $_POST["password"];
    $password2 = $_POST["password2"];

    $usernamepattern = "/^[A-Za-z][A-Za-z0-9_]{5,}/";
    $paspattern = "/(?=^.{8,}$)((?=.*\d)(?=.*[A-Z])(?=.*[a-z])(?=.*[,.!?:;\-%$#@&*^|\/\\~[\]{}]))^.*/";

    if (filter_var($email, FILTER_VALIDATE_EMAIL)
        &&preg_match($usernamepattern, $username)
        &&preg_match($paspattern, $password)
        &&($password == $password2)
    ) {
        $query = "SELECT * FROM `users` WHERE `username`=\"$username\" AND `email`=\"$email\";";
        if (mysqli_num_rows(mysqli_query($conn, $query))==0) {
            $query = "INSERT INTO `users` (email, username, password) VALUES (\"$email\", \"$username\", \"$password\");";
            if (mysqli_query($conn, $query)) {
                header('Location: login.php');
            }
        }
    }
}
?>
    <form action="register.php" method="post" class="form">
        <h2>Register</h2>
        <h4>Email</h4>
        <input name="email" type="email" required><br>
        <h4>Username</h4>
        <input name="username" type="text" required><br>
        <h4>Password</h4>
        <input name="password" type="password" required><br>
        <h4>Repeat Password</h4>
        <input name="password2" type="password" required><br>
        <button type="submit">Register!</button>
    </form>
</div>
<?php
mysql_close($conn);
require "htmlend.php";
?>
