<?php
session_start();
require "db.php";
$conn = mysqli_connect($dbservername, $dbusername, $dbpassword, $dbname);
if ($_SESSION["user"]) {
    $user = $_SESSION["user"];
} else {
    $user = 0;
}
$breed_id = $_GET["breed_id"];
?>

<?php
if ($user["admin"]==1 && $_SERVER["REQUEST_METHOD"]=="POST") {
    $breed = $_POST["breed"];
    $info = $_POST["info"];
    $query = "UPDATE breeds SET breed=\"$breed\", info=\"$info\" WHERE id=$breed_id";
    mysqli_query($conn, $query);
    if ($_FILES["image"]["size"]!=0) {
        $uploadfile = 'images/breed_' . $breed_id;
        move_uploaded_file($_FILES['image']['tmp_name'], $uploadfile);
    }
    header("Location: breed_detail.php?breed_id=$breed_id");
}
?>

<?php
require "htmlstart.php";
require "navbar.php";
?>
<?php
if ($user["admin"]==1) {
    $query = "SELECT * FROM breeds WHERE id=$breed_id";
    $b = mysqli_fetch_assoc(mysqli_query($conn, $query));
    $breed = $b["breed"];
    $info = $b["info"];
    $image = $b["image"];
    echo "
<form class=\"form\" action=\"breed_edit.php?breed_id=$breed_id\" method=\"POST\" enctype=\"multipart/form-data\">
    <h2>Breed Edit</h2>
    <h4 class=\"input-title\">Breed Name:</h4>
    <input name=\"breed\" type=\"text\" value=\"$breed\">
    <h4 class=\"input-title\">Info:</h4>
    <textarea name=\"info\" rows=\"5\">$info</textarea>
    <h4 class=\"input-title\">Image:</h4>
    <img src=\"$image\" class=\"breed-img\">
    <input name=\"image\" type=\"file\"><br>
    <button type=\"submit\">Create!</button>
</form>
    ";
} else {
    echo "<h1>You are not admin!</h1>";
}
?>
<?php
mysql_close($conn);
require "htmlend.php";
?>


<!--<form class="form" action="breed_create.php" method="POST" enctype="multipart/form-data">-->
<!--    <h2>Breed Create</h2>-->
<!--    <h4 class="input-title">Breed Name:</h4>-->
<!--    <input name="breed" type="text">-->
<!--    <h4 class="input-title">Info:</h4>-->
<!--    <textarea name="info" rows="5"></textarea>-->
<!--    <h4 class="input-title">Image:</h4>-->
<!--    <input name="image" type="file"><br>-->
<!--    <button type="submit">Create!</button>-->
<!--</form>-->
