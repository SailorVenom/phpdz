<?php
session_start();
require "db.php";
$conn = mysqli_connect($dbservername, $dbusername, $dbpassword, $dbname);
if ($_SESSION["user"]) {
    $user = $_SESSION["user"];
} else {
    $user = 0;
}

if ($user) {
    $breed_id = $_GET["breed_id"];
    $user_id = $user["id"];
    $rate = $_GET["rate"];
    if ($rate > 5) $rate = 5;
    if ($rate < 1) $rate = 1;
    $query = "SELECT * FROM rates WHERE breed_id=$breed_id AND user_id=$user_id";
    $exist = mysqli_num_rows(mysqli_query($conn, $query));
    if (!$exist) {
        $query = "INSERT INTO rates (breed_id, user_id, rate) VALUES ($breed_id, $user_id, $rate);";
        mysqli_query($conn, $query);
    } else {
//        $query = "DELETE FROM rates WHERE breed_id=$breed_id AND user_id=$user_id";
        $query = "UPDATE rates SET rate=$rate WHERE breed_id=$breed_id AND user_id=$user_id";
        mysqli_query($conn, $query);
    }

    $query = "SELECT * FROM rates WHERE breed_id=$breed_id";
    $res = mysqli_query($conn, $query);
    $numrows = mysqli_num_rows($res);
    $avg = 0.0;
    while ($rate = mysqli_fetch_assoc($res)) {
        $avg+=(float)$rate["rate"];
    }
    $avg = $avg/$numrows;
    $query = "UPDATE breeds SET rating=$avg WHERE id=$breed_id";
    mysqli_query($conn, $query);

}
header("Location: breed_detail.php?breed_id=$breed_id");
mysql_close($conn);
?>


<!--<form class="form" action="breed_create.php" method="POST" enctype="multipart/form-data">-->
<!--    <h2>Breed Create</h2>-->
<!--    <h4 class="input-title">Breed Name:</h4>-->
<!--    <input name="breed" type="text">-->
<!--    <h4 class="input-title">Info:</h4>-->
<!--    <textarea name="info" rows="5"></textarea>-->
<!--    <h4 class="input-title">Image:</h4>-->
<!--    <input name="image" type="file"><br>-->
<!--    <button type="submit">Create!</button>-->
<!--</form>-->
