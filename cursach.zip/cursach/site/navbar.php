<?php
echo "
<body>
<nav class=\"navbar\">
    <div class=\"nav-item\"><a href=\"index.php\">About</a></div>
    <div class=\"nav-item\"><a href=\"breeds.php\">Breeds</a></div>
    <div class=\"nav-item\"><a href=\"gallery.php\">Gallery</a></div>
    <div class=\"nav-item\"><a href=\"contacts.php\">Contacts</a></div>
";
if ($user["admin"]){
    echo "
    <div class=\"nav-item\"><a href=\"breed_create.php\">Create Breed</a></div>
    ";
}
if (!$user) {
    echo "
    <div class=\"nav-item auth\"><a href=\"login.php\" class=\"auth\">Login</a></div>
    <div class=\"nav-item auth\"><a href=\"register.php\" class=\"auth\">Register</a></div>
    ";
} else {
    echo "
    <div class=\"nav-item auth\"><a href=\"logout.php\" class=\"auth\">Logout</a></div>
    ";
}
echo "
</nav>
<div class=\"content\">
";
?>