<?php
session_start();
require "db.php";
$conn = mysqli_connect($dbservername, $dbusername, $dbpassword, $dbname);
if ($_SESSION["user"]) {
    $user = $_SESSION["user"];
} else {
    $user = 0;
}
?>
<?php
require "htmlstart.php";
require "navbar.php";
?>
    <h1>Contacts</h1>
    
      <h2>  Visit cathedra's web-site! <a href="www.iu4.bmstu.ru">IU4</a> </h2>
        <p>PLEASE DONATE ME MONEY ----> PAYPAL: aliengleamh@gmail.com</p>
        <p> OR JUST FEED ME IN CANTEEN </p>

<?php
mysql_close($conn);
require "htmlend.php";
?>