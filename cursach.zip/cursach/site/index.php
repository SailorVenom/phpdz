<?php
session_start();
require "db.php";
$conn = mysqli_connect($dbservername, $dbusername, $dbpassword, $dbname);
if ($_SESSION["user"]) {
    $user = $_SESSION["user"];
} else {
    $user = 0;
}
?>
<?php
require "htmlstart.php";
require "navbar.php";
?>
    <h1>About Us</h1>
    <p>
        I would like to say, I created this web-site for people who love cats and want to know more about breeds. I would like u to comment posts and rate breeds, people should know which breed is the best and why!
        Contacts <a href=\"contacts.php\">here</a>!
    </p>

<?php
mysql_close($conn);
require "htmlend.php";
?>