<?php
session_start();
require "db.php";
$conn = mysqli_connect($dbservername, $dbusername, $dbpassword, $dbname);
if ($_SESSION["user"]) {
    $user = $_SESSION["user"];
} else {
    $user = 0;
}
$breed_id = $_GET["breed_id"];
$query = "SELECT * FROM breeds WHERE id=$breed_id";
$breed = mysqli_fetch_assoc(mysqli_query($conn, $query));
$breed_name = $breed["breed"];
$image = $breed["image"];
$info = $breed["info"];
$rating = $breed["rating"];
?>

<?php
?>

<?php
require "htmlstart.php";
require "navbar.php";
?>
<?php
if ($user["admin"]) {
    echo "
    <hr>
    <div class=\"nav-item\"><a href=\"breed_edit.php?breed_id=$breed_id\">Edit</a></div>
    <div class=\"nav-item\"><a href=\"breed_delete.php?breed_id=$breed_id\">Delete</a></div>
    <hr>
    ";
}
echo "
<div class=\"breed\">
    <h1>$breed_name</h1>
    <img class=\"breed-item breed-img\" src=\"$image\">
    <p class=\"breed-item breed-p\">$info</p>
    <h4>Total Rating: $rating</h4>
</div>
";
if ($user) {
    echo "
<div class=\"rating\">
    <a class=\"rate rate-1\" href=\"rate.php?breed_id=$breed_id&rate=1\">1</a>
    <a class=\"rate rate-2\" href=\"rate.php?breed_id=$breed_id&rate=2\">2</a>
    <a class=\"rate rate-3\" href=\"rate.php?breed_id=$breed_id&rate=3\">3</a>
    <a class=\"rate rate-4\" href=\"rate.php?breed_id=$breed_id&rate=4\">4</a>
    <a class=\"rate rate-5\" href=\"rate.php?breed_id=$breed_id&rate=5\">5</a>
</div>
    ";
}
echo "<div class=\"comments\">";
if ($user) {
    echo "
    <form action=\"comment.php?breed_id=$breed_id\" method=\"POST\">
        <textarea class=\"comment-f\" name=\"comment\" rows=\"5\"></textarea>
        <button type=\"submit\">Comment!</button>
    </form>
    <hr>
    ";
}
$query = "SELECT * FROM comments WHERE breed_id=$breed_id ORDER BY id DESC";
$res = mysqli_query($conn, $query);
while ($c = mysqli_fetch_assoc($res)) {
    $comment = $c["comment"];
    $username = $c["username"];
    echo "
    <p><b>$username: </b>$comment</p>
    ";
}
echo "</div>"
?>
<?php
mysql_close($conn);
require "htmlend.php";
?>


<!--<form class="form" action="breed_create.php" method="POST" enctype="multipart/form-data">-->
<!--    <h2>Breed Create</h2>-->
<!--    <h4 class="input-title">Breed Name:</h4>-->
<!--    <input name="breed" type="text">-->
<!--    <h4 class="input-title">Info:</h4>-->
<!--    <textarea name="info" rows="5"></textarea>-->
<!--    <h4 class="input-title">Image:</h4>-->
<!--    <input name="image" type="file"><br>-->
<!--    <button type="submit">Create!</button>-->
<!--</form>-->
