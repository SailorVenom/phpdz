<?php
$dbservername="localhost";
$dbusername="kate";
$dbpassword="kate";
$dbname="db_kate";
