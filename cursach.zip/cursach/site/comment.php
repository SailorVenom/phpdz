<?php
session_start();
require "db.php";
$conn = mysqli_connect($dbservername, $dbusername, $dbpassword, $dbname);
if ($_SESSION["user"]) {
    $user = $_SESSION["user"];
} else {
    $user = 0;
}

if ($user) {
    $breed_id = $_GET["breed_id"];
    $user_id = $user["id"];
    $comment = $_POST["comment"];
    $username = $user["username"];
    $query = "INSERT INTO comments (breed_id, user_id, comment, username) VALUES ($breed_id, $user_id, \"$comment\", \"$username\")";
    mysqli_query($conn, $query);
}
header("Location: breed_detail.php?breed_id=$breed_id");
mysql_close($conn);
?>


<form class="form" action="breed_create.php" method="POST" enctype="multipart/form-data">-
<h2>Breed Create</h2>
<h4 class="input-title">Breed Name:</h4>
<input name="breed" type="text">
<h4 class="input-title">Info:</h4>
<textarea name="info" rows="5"></textarea>
<h4 class="input-title">Image:</h4>
<input name="image" type="file"><br>
<button type="submit">Create!</button>
</form>
