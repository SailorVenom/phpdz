<?php
session_start();
require "db.php";
$conn = mysqli_connect($dbservername, $dbusername, $dbpassword, $dbname);
if ($_SESSION["user"]) {
    $user = $_SESSION["user"];
} else {
    $user = 0;
}
$breed_id = $_GET["breed_id"];
?>
<?php
if ($user["admin"]==1) {
    $query = "DELETE FROM breeds WHERE id=$breed_id";
    mysqli_query($conn, $query);
    $query = "DELETE FROM comments WHERE breed_id=$breed_id";
    mysqli_query($conn, $query);
    $query = "DELETE FROM rates WHERE breed_id=$breed_id";
    mysqli_query($conn, $query);
    header("Location: breeds.php");
}
?>
<?php
mysql_close($conn);
require "htmlend.php";
?>


<!--<form class="form" action="breed_create.php" method="POST" enctype="multipart/form-data">-->
<!--    <h2>Breed Create</h2>-->
<!--    <h4 class="input-title">Breed Name:</h4>-->
<!--    <input name="breed" type="text">-->
<!--    <h4 class="input-title">Info:</h4>-->
<!--    <textarea name="info" rows="5"></textarea>-->
<!--    <h4 class="input-title">Image:</h4>-->
<!--    <input name="image" type="file"><br>-->
<!--    <button type="submit">Create!</button>-->
<!--</form>-->
