<?php
session_start();
require "db.php";
$conn = mysqli_connect($dbservername, $dbusername, $dbpassword, $dbname);
if ($_SESSION["user"]) {
    $user = $_SESSION["user"];
} else {
    $user = 0;
}
?>

<?php
if ($user["admin"]==1 && $_SERVER["REQUEST_METHOD"]=="POST") {
    $breed = $_POST["breed"];
    $info = $_POST["info"];
    $query = "INSERT INTO breeds (breed, info) VALUES (\"$breed\", \"$info\")";
    mysqli_query($conn, $query);
    $breed_id = $conn->insert_id;

    $uploadfile = 'images/breed_' . $breed_id;
    if (move_uploaded_file($_FILES['image']['tmp_name'], $uploadfile)) {
        $request = "UPDATE breeds SET image = \"$uploadfile\" WHERE `id` = $breed_id";
        mysqli_query($conn, $request);
    }
    header("Location: breeds.php");
}
?>

<?php
require "htmlstart.php";
require "navbar.php";
?>
<?php
if ($user["admin"]==1) {
    echo "
<form class=\"form\" action=\"breed_create.php\" method=\"POST\" enctype=\"multipart/form-data\">
    <h2>Breed Create</h2>
    <h4 class=\"input-title\">Breed Name:</h4>
    <input name=\"breed\" type=\"text\">
    <h4 class=\"input-title\">Info:</h4>
    <textarea name=\"info\" rows=\"5\"></textarea>
    <h4 class=\"input-title\">Image:</h4>
    <input name=\"image\" type=\"file\"><br>
    <button type=\"submit\">Create!</button>
</form>
    ";
} else {
    echo "<h1>You are not admin!</h1>";
}
?>

<?php
mysql_close($conn);
require "htmlend.php";
?>


<!--<form class="form" action="breed_create.php" method="POST" enctype="multipart/form-data">-->
<!--    <h2>Breed Create</h2>-->
<!--    <h4 class="input-title">Breed Name:</h4>-->
<!--    <input name="breed" type="text">-->
<!--    <h4 class="input-title">Info:</h4>-->
<!--    <textarea name="info" rows="5"></textarea>-->
<!--    <h4 class="input-title">Image:</h4>-->
<!--    <input name="image" type="file"><br>-->
<!--    <button type="submit">Create!</button>-->
<!--</form>-->
